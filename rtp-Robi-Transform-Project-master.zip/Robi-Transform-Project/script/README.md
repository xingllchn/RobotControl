# scripts used during development and dbg

1. cp.sh: copy the modified *.py file to source directory <br/>
2. dbg_robi.sh: open a lot of terminals/dirs at raspberry startup <br/>

2016.10.9 <br/>


