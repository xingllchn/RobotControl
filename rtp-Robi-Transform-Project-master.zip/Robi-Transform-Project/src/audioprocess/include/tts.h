
#ifndef TTS
  #define TTS

#include "audio_cmn.h"

#define USE_XUNFEI_ONL_TTS


//int tts(const char *text, const char *args);
int tts(const char *text);

#endif

