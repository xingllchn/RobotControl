#include "Python.h"

#ifndef __CPU_RPI2B__    //__CPU_Exynos4412__
 #define __CPU_RPI2B__   //__BCM2836__   
#endif

//#define __DEBUG__        //
#define __PWM_SERIALISE_MODE__

