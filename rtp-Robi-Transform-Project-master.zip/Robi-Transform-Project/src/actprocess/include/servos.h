
#ifndef __CPU_RPI3B__    //__CPU_Exynos4412__
 #define __CPU_RPI3B__   //__BCM2837__   
#endif


//#define SUCCEEDED  3
#define ALLOWABLE_DIFF     30        // 20=2'
#define INTVL_INQ_POSITION 300       // 300=300ms
#define MAX_INQ_TIMES      10 
