#ifndef WDG_WKUP_H
#define WDG_WKUP_H

#ifdef __cplusplus
extern "C" {
#endif 

#include "stm32f10x.h"

void PB_IWDG_Init(void);
void PB_IWDG_Feed(void);

void PB_WWDG_Init(u8 tr, u8 wr, u32 fprer);//Initialize WDG
void PB_WWDG_Set_Counter(u8 cnt);       //Set the counter of WDG

#define WKUP_KD  GPIOA->IDR & GPIO_Pin_0		//PA0 check if have WK_UP KEY pressed
void PB_WKUP_Init(void); 			//PA0 WKUP Initialization

#ifdef __cplusplus
}
#endif 	

#endif // #ifndef WDG_WKUP_H
