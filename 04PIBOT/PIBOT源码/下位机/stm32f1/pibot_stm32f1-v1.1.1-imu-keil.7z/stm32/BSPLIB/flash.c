
#ifdef __cplusplus
extern "C" {
#endif 

#include "flash.h"


u16 PB_Flash_ReadHalfWord(u32 faddr){
    uint16_t val = 0;
    faddr = faddr + FLASH_SAVE_ADDR;
    val = *(uint16_t*)faddr;

    return val;
}

u32 PB_Flash_ReadWord(u32 faddr){
    uint16_t val = 0;
    faddr = faddr + FLASH_SAVE_ADDR;
    val = *(uint32_t*)faddr;

    return val;
}
#define PageSize  0x400
void PB_Flash_EnableWrite(){
    /*FLASH_Unlock();
    FLASH_ErasePage(FLASH_SAVE_ADDR);
    CLEAR_BIT(FLASH->CR, FLASH_CR_PER);*/
    FLASH_Unlock();  
    FLASH_ClearFlag(FLASH_FLAG_BSY|FLASH_FLAG_EOP|FLASH_FLAG_PGERR|FLASH_FLAG_WRPRTERR);  
    FLASH_ErasePage(FLASH_SAVE_ADDR);
    //FLASH_ErasePage(FLASH_SAVE_ADDR + PageSize);
}

void PB_Flash_DisableWrite(){
    FLASH_Lock();
}

u32 PB_Flash_WriteHalfWord(u32 faddr, u16 data){
    faddr = faddr +FLASH_SAVE_ADDR;

    return FLASH_ProgramHalfWord(faddr, data);
}

u32 PB_Flash_WriteWord(u32 faddr, u32 data){
    faddr = faddr +FLASH_SAVE_ADDR;

    return FLASH_ProgramWord(faddr, data);
}



#ifdef __cplusplus
}
#endif 
