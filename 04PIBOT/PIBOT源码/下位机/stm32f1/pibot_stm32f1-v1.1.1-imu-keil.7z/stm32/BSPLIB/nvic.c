
#ifdef __cplusplus
extern "C" {
#endif 

#include "nvic.h"


void CAN1_NVIC_Configuration(void) 
{
    NVIC_InitTypeDef NVIC_InitStructure;
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    NVIC_InitStructure.NVIC_IRQChannel = USB_LP_CAN1_RX0_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;  //PreemptionPriority  0--4 Lower value, Higher Priority.
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;	       //SubPriority 0--4 Lower value, Higher Priority.
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;		         //ENABLE Interrupt
    NVIC_Init(&NVIC_InitStructure);
}	

void CAN2_NVIC_Configuration(void) 
{
    //	NVIC_InitTypeDef NVIC_InitStructure;
    //	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    //	NVIC_InitStructure.NVIC_IRQChannel = USB_LP_CAN1_RX0_IRQn;
    //	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;  //PreemptionPriority  0--4 Lower value, Higher Priority.
    //	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;	       //SubPriority 0--4 Lower value, Higher Priority.
    //	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;		         //ENABLE Interrupt
    //	NVIC_Init(&NVIC_InitStructure);
}	

void USART1_NVIC_Configuration(void) 
{
    NVIC_InitTypeDef NVIC_InitStructure;
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;  //PreemptionPriority  0--4 Lower value, Higher Priority.
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;	       //SubPriority 0--4 Lower value, Higher Priority.
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;		         //ENABLE Interrupt
    NVIC_Init(&NVIC_InitStructure);
}	

void USART2_NVIC_Configuration(void) 
{
    NVIC_InitTypeDef NVIC_InitStructure;
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    NVIC_InitStructure.NVIC_IRQChannel = USART2_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;  //PreemptionPriority  0--4 Lower value, Higher Priority.
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;	       //SubPriority 0--4 Lower value, Higher Priority.
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;		         //ENABLE Interrupt
    NVIC_Init(&NVIC_InitStructure);
}	

void USART3_NVIC_Configuration(void) 
{
    NVIC_InitTypeDef NVIC_InitStructure;
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    NVIC_InitStructure.NVIC_IRQChannel = USART3_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;  //PreemptionPriority  0--4 Lower value, Higher Priority.
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;	       //SubPriority 0--4 Lower value, Higher Priority.
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;		         //ENABLE Interrupt
    NVIC_Init(&NVIC_InitStructure);
}	

void UART4_NVIC_Configuration(void) 
{

}	

void UART5_NVIC_Configuration(void) 
{

}	

void TIM1_NVIC_Configuration(void) 
{
    NVIC_InitTypeDef NVIC_InitStructure;
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    NVIC_InitStructure.NVIC_IRQChannel = TIM1_UP_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2;  //PreemptionPriority  0--4 Lower value, Higher Priority.
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;	       //SubPriority 0--4 Lower value, Higher Priority.
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;		         //ENABLE Interrupt
    NVIC_Init(&NVIC_InitStructure);
}	

void TIM2_NVIC_Configuration(void) 
{
    NVIC_InitTypeDef NVIC_InitStructure;
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    NVIC_InitStructure.NVIC_IRQChannel = TIM2_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2;  //PreemptionPriority  0--4 Lower value, Higher Priority.
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;	       //SubPriority 0--4 Lower value, Higher Priority.
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;		         //ENABLE Interrupt
    NVIC_Init(&NVIC_InitStructure);
}	

void TIM3_NVIC_Configuration(void) 
{
    NVIC_InitTypeDef NVIC_InitStructure;
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    NVIC_InitStructure.NVIC_IRQChannel = TIM3_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2;  //PreemptionPriority  0--4 Lower value, Higher Priority.
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;	       //SubPriority 0--4 Lower value, Higher Priority.
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;		         //ENABLE Interrupt
    NVIC_Init(&NVIC_InitStructure);
}	

void TIM4_NVIC_Configuration(void) 
{
    NVIC_InitTypeDef NVIC_InitStructure;
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    NVIC_InitStructure.NVIC_IRQChannel = TIM4_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2;  //PreemptionPriority  0--4 Lower value, Higher Priority.
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;	       //SubPriority 0--4 Lower value, Higher Priority.
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;		         //ENABLE Interrupt
    NVIC_Init(&NVIC_InitStructure);
}	

void TIM5_NVIC_Configuration(void) 
{

}	

void TIM6_NVIC_Configuration(void) 
{

}	

void TIM7_NVIC_Configuration(void) 
{

}	

void TIM8_NVIC_Configuration(void) 
{

}	

void EXTI0_NVIC_Configuration(void) 
{
    NVIC_InitTypeDef NVIC_InitStructure;
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    NVIC_InitStructure.NVIC_IRQChannel = EXTI0_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
}	

void EXTI1_NVIC_Configuration(void) 
{
    NVIC_InitTypeDef NVIC_InitStructure;
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    NVIC_InitStructure.NVIC_IRQChannel = EXTI1_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
}	

void EXTI2_NVIC_Configuration(void) 
{
    NVIC_InitTypeDef NVIC_InitStructure;
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    NVIC_InitStructure.NVIC_IRQChannel = EXTI2_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
}

void EXTI3_NVIC_Configuration(void) 
{
    NVIC_InitTypeDef NVIC_InitStructure;
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    NVIC_InitStructure.NVIC_IRQChannel = EXTI3_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
}

void EXTI4_NVIC_Configuration(void) 
{
    NVIC_InitTypeDef NVIC_InitStructure;
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    NVIC_InitStructure.NVIC_IRQChannel = EXTI4_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
}

void EXTI9_5_NVIC_Configuration(void) 
{
    NVIC_InitTypeDef NVIC_InitStructure;
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    NVIC_InitStructure.NVIC_IRQChannel = EXTI9_5_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
}	

void EXTI15_10_NVIC_Configuration(void) 
{
    NVIC_InitTypeDef NVIC_InitStructure;
    NVIC_InitStructure.NVIC_IRQChannel = EXTI15_10_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority= 2;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
}	


#ifdef __cplusplus
}
#endif 
