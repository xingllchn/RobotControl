
#ifdef __cplusplus
extern "C" {
#endif 

#include "wdg_wkup.h"
#include "delay.h"

void PB_IWDG_Init(void) 
{
    IWDG_WriteAccessCmd(IWDG_WriteAccess_Enable); 	//Enable access to write register
    IWDG_SetPrescaler(IWDG_Prescaler_64);           //Frequency: 40K / 64 =  0.625K, and one cycle is 1.6ms
    IWDG_SetReload(800);							              //800*1.6ms = 1.28S
    IWDG_ReloadCounter();								//the program to feed dog, if not write 0xAAAA every while, WDG will reset
    IWDG_Enable(); 									    //enable
}

void PB_IWDG_Feed(void)
{   
    IWDG_ReloadCounter();	  						   
}

static void WWDG_NVIC_Init()
{
    NVIC_InitTypeDef NVIC_InitStructure;
    NVIC_InitStructure.NVIC_IRQChannel = WWDG_IRQn;    //WWDG  interrupt
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2;   //PreemptionPriority
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 3;	 //SubPriority 
    NVIC_Init(&NVIC_InitStructure);//NVIC initialization
}

u8 WWDG_CNT=0x7f;
void PB_WWDG_Init(u8 tr,u8 wr,u32 fprer)
{ 
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_WWDG, ENABLE);  // enable  WWDG clock
    WWDG_SetPrescaler(fprer);  //set IWDG Prescaler
    WWDG_SetWindowValue(wr);   //set window value
    WWDG_Enable(tr);	         //enable WWDG, and set counter
    WWDG_ClearFlag();
    WWDG_NVIC_Init();          //initialize WWDG NVIC
    WWDG_EnableIT();           //enable interrupt of WWDG
} 

void PB_WWDG_Set_Counter(u8 cnt)
{
    WWDG_Enable(cnt);	 
}

void PB_WWDG_IRQHandler(void)
{
    
    WWDG_SetCounter(0x7F);	  //if annotate this words, WWDG will reset
    WWDG_ClearFlag();	        //clear flag of advance wake up
}


static void Sys_Standby(void)
{  
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR, ENABLE);	//ENABLE PWR clock 
    PWR_WakeUpPinCmd(ENABLE);  //enable the wake-up Pin
    PWR_EnterSTANDBYMode();	  //enter standby mode
}

static void Sys_Enter_Standby(void)
{			 
    RCC_APB2PeriphResetCmd(0X01FC,DISABLE);	//RESET all IO
    Sys_Standby();
}

static  u8 Check_WKUP(void) 
{
    u8 t=0;	//recording the time when pressing
    //	LED0=0; 
    while(1)
    {
        if(WKUP_KD)
        {
            t++;			//have pressed
            delay_ms(30);
            if(t>=100)		//having been pressed over 3s
            {
                //				LED0=0;	 	//light DS0 
                return 1; 	//having been pressed over 3s
            }
        }else 
        { 
            //			LED0=1;
            return 0; //having been pressed short 3s
        }
    }
} 

void PB_WKUP_Init(void)
{	
    
    GPIO_InitTypeDef  GPIO_InitStructure;  		  
    NVIC_InitTypeDef NVIC_InitStructure;
    EXTI_InitTypeDef EXTI_InitStructure;
    
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_AFIO, ENABLE);
    
    GPIO_InitStructure.GPIO_Pin =GPIO_Pin_0;	 //PA.0
    GPIO_InitStructure.GPIO_Mode =GPIO_Mode_IPD;//pull up input
    GPIO_Init(GPIOA, &GPIO_InitStructure);	//Initialize IO
    //use external interrupt 
    GPIO_EXTILineConfig(GPIO_PortSourceGPIOA, GPIO_PinSource0);	//connect Interrupt Line 0 with GPIOA
    
    EXTI_InitStructure.EXTI_Line = EXTI_Line0;	//set all line of key
    EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;			//use external interrupt mode
    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising;  //response at posedge
    EXTI_InitStructure.EXTI_LineCmd = ENABLE;
    EXTI_Init(&EXTI_InitStructure);	// initialize external interruption
    
    NVIC_InitStructure.NVIC_IRQChannel = EXTI0_IRQn; //enable external interrupt line of key
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2; 
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2; 
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE; //enable external interrupt channel
    NVIC_Init(&NVIC_InitStructure); 
    
    if(Check_WKUP()==0) Sys_Standby();    //enter standby mode
    
}

#ifdef __cplusplus
}
#endif 




