#ifndef ENCODER_H
#define ENCODER_H

#ifdef __cplusplus
extern "C" {
#endif 

#include "stm32f10x.h"

void PB_Encoder_Init(TIM_TypeDef* TIMx , unsigned char GPIO_AF);
float PB_Get_Encode_TIM5(void);//What you get here is the total angle.
float PB_Get_Encode_TIM4(void);
float PB_Get_Encode_TIM3(void);
float PB_Get_Encode_TIM2(void);

#ifdef __cplusplus
}
#endif 

#endif // #ifndef ENCODER_H


