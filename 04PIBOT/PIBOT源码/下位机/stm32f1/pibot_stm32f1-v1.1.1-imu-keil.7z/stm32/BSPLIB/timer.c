#ifdef __cplusplus
extern "C" {
#endif 

#include "timer.h"
#include "nvic.h"

void PB_Timer_Init(TIM_TypeDef* TIMx, uint32_t Time_us)
{
    TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;

    if( TIMx == TIM2){
        RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2 , ENABLE); /* enable clock */
        TIM2_NVIC_Configuration();    //enable interruptation
    }
    else if( TIMx == TIM3){
        RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3 , ENABLE); /* enable clock */
        TIM3_NVIC_Configuration();     //enable interruptation
    }
    else if( TIMx == TIM4){
        RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4 , ENABLE); /* enable clock */
        TIM4_NVIC_Configuration();    //enable interruptation
    }
    else if( TIMx == TIM5){
        RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM5 , ENABLE); /* enable clock */
        TIM5_NVIC_Configuration();    //enable interruptation
    }
    else if( TIMx == TIM6){
        RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM6 , ENABLE); /* enable clock */
        TIM6_NVIC_Configuration();    //enable interruptation
    }
    else if( TIMx == TIM7){
        RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM7 , ENABLE); /* enable clock */
        TIM7_NVIC_Configuration();    //enable interruptation
    }
    TIM_DeInit(TIMx);
    TIM_TimeBaseStructure.TIM_Period= Time_us-1; 					/* the value of auto reload register  */
    TIM_TimeBaseStructure.TIM_Prescaler= (72 - 1);				    /* prescler : 72M/72 */
    TIM_TimeBaseStructure.TIM_ClockDivision=TIM_CKD_DIV1; 		/* ClockDivision*/
    TIM_TimeBaseStructure.TIM_CounterMode=TIM_CounterMode_Up; /* count upwards */
    TIM_TimeBaseInit(TIMx , &TIM_TimeBaseStructure);
    TIM_ClearFlag(TIMx , TIM_FLAG_Update);							    		/* clear interrupt flags */
    TIM_ITConfig(TIMx ,TIM_IT_Update,ENABLE);
    TIM_Cmd(TIMx , ENABLE);
}	

#ifdef __cplusplus
}
#endif 

