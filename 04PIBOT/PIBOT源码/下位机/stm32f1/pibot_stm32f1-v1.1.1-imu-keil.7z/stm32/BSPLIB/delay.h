#ifndef DELAY_H
#define DELAY_H

#ifdef __cplusplus
extern "C" {
#endif

#include "stm32f10x.h"

/**********************************************************************************************************************/
void delay_ms(uint16_t t);    //using timer to delay time, max delay time is 1864ms
void delay_us(uint16_t t);    //using timer to delay time, max delay time is 1864ms
/**********************************************************************************************************************/
void PB_System_Timer_Init(void);  //Initialize the Time measurement system
float PB_Get_System_Time(void);   //Return the current time(us), max:281474976s--->3257.8 days
float PB_Get_Dtime(void);         // Return the time difference(us). max:655s

#ifdef __cplusplus
}
#endif

#endif  // #ifndef DELAY_H
