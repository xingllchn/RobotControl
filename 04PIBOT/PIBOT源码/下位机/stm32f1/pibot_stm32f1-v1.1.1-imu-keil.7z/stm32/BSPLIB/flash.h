#ifndef FLASH_H
#define FLASH_H
#ifdef __cplusplus
extern "C" {
#endif 

#include "stm32f10x.h"

#define FLASH_SAVE_ADDR ((uint32_t)0x800FC00)

u16 PB_Flash_ReadHalfWord(u32 faddr);
u32 PB_Flash_ReadWord(u32 faddr);

void PB_Flash_EnableWrite(void);
void PB_Flash_DisableWrite(void);
u32 PB_Flash_WriteHalfWord(u32 faddr, u16 data);
u32 PB_Flash_WriteWord(u32 faddr, u32 data);

#ifdef __cplusplus
}
#endif 

#endif // #ifndef FLASH_H


