#ifndef __i2c_H__
#define __i2c_H__

#ifdef __cplusplus
extern "C" {
#endif 

#include "stm32f10x.h" 

#define SCL_H         GPIOB->BSRR = GPIO_Pin_8
#define SCL_L         GPIOB->BRR  = GPIO_Pin_8 

#define SDA_H         GPIOB->BSRR = GPIO_Pin_9
#define SDA_L         GPIOB->BRR  = GPIO_Pin_9 

#define SCL_read      GPIOB->IDR  & GPIO_Pin_8
#define SDA_read      GPIOB->IDR  & GPIO_Pin_9 

/*********************************************************************************************************************/

void PB_I2C_Init(void);
int PB_I2C_Write_Byte(uint8_t addr, uint8_t reg, uint8_t data);
int PB_I2C_Write_Buf(uint8_t addr, uint8_t reg, uint8_t *data, uint8_t size);

int PB_I2C_Read_Byte(uint8_t addr, uint8_t reg, uint8_t* data);
int PB_I2C_Read_Buf(uint8_t addr,uint8_t reg, uint8_t* data, uint8_t size);


#ifdef __cplusplus
}
#endif 

#endif //__i2c_H__


