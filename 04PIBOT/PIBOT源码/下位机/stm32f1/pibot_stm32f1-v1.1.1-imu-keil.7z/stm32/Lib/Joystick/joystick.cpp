#include "joystick.h"

#include "board.h"
#include <stdio.h>

#define pressures   false
#define rumble      false

Joystick::Joystick(){
}

bool Joystick::init(){
	printf("init joystick\r\n");
	//PS2_SetInit();
#if 0
	unsigned long start = Board::get()->get_tick_count();
	while(Board::get()->get_tick_count()-start>500){
		;
	}
    error = ps2x.config_gamepad(PS2_CLK, PS2_CMD, PS2_SEL, PS2_DAT, pressures, rumble);
	if (error == 0)
	{
		printf("Teleop start\r\n");
        return true;
	}

	if (error == 1)
		printf("No controller found, check wiring, see readme.txt to enable debug. visit www.billporter.info for troubleshooting tips\r\n");
	else if (error == 2)
		printf("Controller found but not accepting commands. see readme.txt to enable debug. Visit www.billporter.info for troubleshooting tips\r\n");
	else if (error == 3)
		printf("Controller refusing to enter Pressures mode, may not support it. \r\n");
	else
		printf("Teleop err\r\n");
#endif
    return false;
}

#define JOYSTICK_TEST
void Joystick::test(){
#ifdef JOYSTICK_TEST

	unsigned char key=PS2_DataKey();
	if(key!=0)                   //有按键按下
	{
		switch (key)
		{
			case PSB_SELECT:
				printf("SELECT\r\n");
				break;
			case PSB_L3:
				printf("L3\r\n");
				break;
			case PSB_R3:
				printf("R3\r\n");
				break;
			case PSB_START:
				printf("START\r\n");
				break;
			case PSB_PAD_UP:
				printf("UP\r\n");
				break;
			case PSB_PAD_RIGHT:
				printf("RIGHT\r\n");
				break;
			case PSB_PAD_DOWN:
				printf("DOWN\r\n");
				break;
			case PSB_PAD_LEFT:
				printf("LEFT\r\n");
				break;
			case PSB_L2:
				printf("L2\r\n");
				break;
			case PSB_R2:
				printf("R2\r\n");
				break;
			case PSB_L1:
				printf("L1\r\n");
				break;
			case PSB_R1:
				printf("R1\r\n");
				break;
			case PSB_TRIANGLE:
				printf("TRIANGLE\r\n");
				break;
			case PSB_CIRCLE:
				printf("CIRCLE\r\n");
				break;
			case PSB_CROSS:
				printf("CROSS\r\n");
				break;
			case PSB_SQUARE:
				printf("SQUARE\r\n");
				break;
			default:
				printf("UNKNOWN\r\n");
				break;
		}
	}

	printf("(need to switch mode) %5d %5d %5d %5d\r\n",PS2_AnologData(PSS_LX),PS2_AnologData(PSS_LY), PS2_AnologData(PSS_RX),PS2_AnologData(PSS_RY) );
#endif
}

bool Joystick::check(short& liner_x, short liner_y, short& angular_z){
	#if JOYSTICK_FOR_HOLONOMIC
		return holonomic_check(liner_x, liner_y, angular_z);
	#else
		return nonholonomic_check(liner_x, liner_y, angular_z);
	#endif

	return false;
}

bool Joystick::holonomic_check(short& liner_x, short liner_y, short& angular_z){
	bool rtn = false;

	unsigned char key=PS2_DataKey();
	
	//up down left right  for liner x, y
	if (key == PSB_PAD_UP)
	{
	#if JOYSTICK_DEBUG_ENABLE
      	printf("UP");
	#endif
		liner_x = MAX_LINER_X;
		rtn = true;
	}
    if(key == PSB_PAD_DOWN){
	#if JOYSTICK_DEBUG_ENABLE
      	printf("DOWN");
	#endif
		liner_x = -MAX_LINER_X;
		rtn = true;
    }
    if(key == PSB_PAD_RIGHT){
	#if JOYSTICK_DEBUG_ENABLE
		printf("RIGHT");
	#endif
		liner_y = MAX_LINER_Y;
		rtn = true;
    }
    if(key == PSB_PAD_LEFT){
	#if JOYSTICK_DEBUG_ENABLE
      	printf("LEFT");
	#endif
		liner_y = -MAX_LINER_Y;
		rtn = true;
    }
	
	//triangle square circle cross  for angular z
	if (key == PSB_SQUARE)
	{
	#if JOYSTICK_DEBUG_ENABLE
      	printf("SQUARE");
	#endif
		angular_z = MAX_ANGULAR_Z;
		rtn = true;
	}
    if(key == PSB_CIRCLE){
	#if JOYSTICK_DEBUG_ENABLE
      	printf("CIRCLE");
	#endif
		angular_z = -MAX_ANGULAR_Z;
		rtn = true;
    }

	if (key == PSB_L1) { //print stick values if either is TRUE
	#if JOYSTICK_DEBUG_ENABLE
		printf("Stick Values:");
		printf("%d", PS2_AnologData(PSS_LY));
		printf(",");
		printf("%d", PS2_AnologData(PSS_LX));
		printf(",");
		printf("%d", PS2_AnologData(PSS_RY));
		printf(",");
		printf("%d\r\n", PS2_AnologData(PSS_RX));
	#endif

		if (PS2_AnologData(PSS_LX) == 255 && PS2_AnologData(PSS_LX) == 255 &&
		PS2_AnologData(PSS_LX) == 255 && PS2_AnologData(PSS_LX) == 255)
		{
	#if JOYSTICK_DEBUG_ENABLE
		printf("switch mode for use rocker\r\n");
	#endif
		}
		else
		{
			liner_x = ((255.0/2)-PS2_AnologData(PSS_LY))/(255.0/2)*MAX_LINER_X;
			liner_y = ((255.0/2)-PS2_AnologData(PSS_LX))/(255.0/2)*MAX_LINER_Y;
			angular_z = ((255.0/2)-PS2_AnologData(PSS_RX))/(255.0/2)*MAX_ANGULAR_Z;
			rtn = true;
		}
	}

	return rtn;
}

bool Joystick::nonholonomic_check(short& liner_x, short liner_y, short& angular_z){
	
	liner_y = 0;
	
	bool rtn = false;

	unsigned char key=PS2_DataKey();
	
	if (key == PSB_PAD_UP)               //will be TRUE if button was JUST pressed
	{
	#if JOYSTICK_DEBUG_ENABLE
      	printf("Up held this hard: ");
	#endif
		liner_x = MAX_LINER_X;
		rtn = true;
	}
    if(key == PSB_PAD_RIGHT){
	#if JOYSTICK_DEBUG_ENABLE
		printf("Right held this hard: ");
	#endif
		angular_z = MAX_ANGULAR_Z;
		rtn = true;
    }
    if(key == PSB_PAD_LEFT){
	#if JOYSTICK_DEBUG_ENABLE
      	printf("LEFT held this hard: ");
	#endif
		angular_z = -MAX_ANGULAR_Z;
		rtn = true;
    }
    if(key == PSB_PAD_DOWN){
	#if JOYSTICK_DEBUG_ENABLE
      	printf("DOWN held this hard: ");
	#endif
		liner_x = -MAX_LINER_X;
		rtn = true;
    }


	if (key == PSB_L1) { //print stick values if either is TRUE
	#if JOYSTICK_DEBUG_ENABLE
		printf("Stick Values:");
		printf("%d", PS2_AnologData(PSS_LY));
		printf(",");
		printf("%d", PS2_AnologData(PSS_LX));
		printf(",");
		printf("%d", PS2_AnologData(PSS_RY));
		printf(",");
		printf("%d\r\n", PS2_AnologData(PSS_RX));
	#endif

		if (PS2_AnologData(PSS_LX) == 255 && PS2_AnologData(PSS_LX) == 255 &&
		PS2_AnologData(PSS_LX) == 255 && PS2_AnologData(PSS_LX) == 255)
		{
	#if JOYSTICK_DEBUG_ENABLE
		printf("switch mode for use rocker\r\n");
	#endif
		}
		else
		{
			liner_x = ((255.0/2)-PS2_AnologData(PSS_LY))/(255.0/2)*MAX_LINER_X;
			angular_z = ((255.0/2)-PS2_AnologData(PSS_LX))/(255.0/2)*MAX_ANGULAR_Z;
			rtn = true;
		}
	}

	return rtn;
}