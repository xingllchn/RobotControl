#include "data_holder.h"
#include "board.h"
#include <stdio.h>
Data_holder::Data_holder(){
    strncpy((char*)&firmware_info.version, "v1.1.1", strlen("v1.1.1"));
    sprintf(firmware_info.time, "%s-m%de%d", "20180801",
                            MOTOR4_REVERSE<<3 | MOTOR3_REVERSE<<2 | MOTOR2_REVERSE<<1 | MOTOR1_REVERSE,
                            ENCODER4_REVERSE<<3 | ENCODER3_REVERSE<<2 | ENCODER2_REVERSE<<1 | ENCODER1_REVERSE);
    memset(&parameter, 0, sizeof(struct Robot_parameter));
    memset(&velocity, 0, sizeof(struct Robot_velocity));
    memset(&odom, 0, sizeof(struct Robot_odom));
    memset(&pid_data, 0, sizeof(struct Robot_pid_data));
    memset(imu_data, 0, sizeof(imu_data));

  /*  parameter.wheel_diameter=63;
    parameter.wheel_track=175;
    parameter.encoder_resolution=1980;
    parameter.do_pid_interval=10;
    parameter.kp=250;
    parameter.ki=2500;
    parameter.kd=0;
    parameter.ko=10;
    parameter.cmd_last_time=150;
    parameter.max_v_liner_x=40;
    parameter.max_v_liner_y=0;
    parameter.max_v_angular_z=150;*/
}

void Data_holder::load_parameter(){
    Board::get()->get_config((unsigned char*)&parameter, sizeof(parameter));
}

void Data_holder::save_parameter(){
    Board::get()->set_config((unsigned char*)&parameter, sizeof(parameter));
}
    

