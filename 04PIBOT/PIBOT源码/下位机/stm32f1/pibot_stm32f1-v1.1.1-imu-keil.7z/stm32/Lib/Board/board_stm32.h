#ifndef PIBOT_BOARD_MEGA2560_H_
#define PIBOT_BOARD_MEGA2560_H_

#include "board.h"
#include "variable_queue.h"


class Board_STM32 : public Board{
  public:
    Board_STM32();
    ~Board_STM32();
    void init();
    void enable_irq();
    void disable_irq();
    void usart_debug_init();
    void usart_write(unsigned char num, unsigned char ch);
    void usart_init(unsigned char num, unsigned long buad);
    Queue* usart_getDataQueue(unsigned char num);

    void usart_write(unsigned char num, unsigned char* data, unsigned char len);

    void set_config(unsigned char* data, unsigned short len);
    void get_config(unsigned char* data, unsigned short len);

    void setDOState(unsigned char id, unsigned char operation);
    bool getDIState(unsigned char id);

    unsigned long get_tick_count();

    void motor_init(unsigned char num, unsigned long period);
    void motor_pwm(unsigned char num, long pwm_value);
    
    void encoder_init(unsigned char motor_id) ;
    long get_encoder_count(unsigned char motor_id);

    void i2c_init();
    unsigned char i2c_write_byte(unsigned char equipment_address, unsigned char reg_address , unsigned char pt_char);
    unsigned char i2c_write_buf(unsigned char equipment_address, unsigned char reg_address , unsigned char* pt_char , unsigned char size);
    unsigned char i2c_read_byte(unsigned char equipment_address, unsigned char reg_address , unsigned char* pt_char);
    unsigned char i2c_read_buf(unsigned char equipment_address, unsigned char reg_address , unsigned char* pt_char, unsigned char size);

  private:
    void DOInit(void);
    void DIInit(void);
  public:
    static Board_STM32 board;

    VQueue<256> usart3_queue;
};

#endif
