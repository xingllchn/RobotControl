#include "robot.h"

int main(void)
{
	Robot::get()->init();

	while (1)
	{
		Robot::get()->check_command();
    	Robot::get()->do_kinmatics();
    	Robot::get()->calc_odom();
    	Robot::get()->get_imu_data();
    	Robot::get()->check_joystick();
	} 								    
}


